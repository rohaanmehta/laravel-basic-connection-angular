<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Angular JS</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script src="<?= url('assets\js\angular.js')?>"></script>
</head>
<body>
<!-- <input type="text" name="_token" id="token" value="<//?php echo csrf_token(); ?>"> -->

<div ng-app='myapp'  ng-controller="mycontroller">
    <h2>{{message}}</h2>
    <label>Name</label>
    <input type='text' ng-model='name'><br>
    <label>Email</label>
    <input type='text' ng-model='email'><br>
    <label>Phone</label>
    <input type='text' ng-model='phone'><br>
    <button ng-click="submit()"> Submit </button>
</div>
    <script>
        var myapp = angular.module('myapp',[]);
        myapp.controller('mycontroller',function($scope,$http){
            $scope.message = 'Welcome to the Angular';
            $scope.submit = function() {
                $scope.message ='function running';
                $http({
                    method : 'POST', 
                    url : '<?= url('/insertdata')?>',
                    data : 'name='+$scope.name+'&&email='+$scope.email+'&&phone='+$scope.phone,
                    headers : {'Content-Type': 'application/x-www-form-urlencoded'}
                });
            };
        });
    </script>
</body>
</html>