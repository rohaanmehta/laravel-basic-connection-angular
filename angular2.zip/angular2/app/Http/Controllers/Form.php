<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;

class Form extends BaseController
{
    //insert api
    public function insertdata(){
        $data = array(
            'name'=>$_POST['name'],
            'email'=>$_POST['email'],
            'phone'=>$_POST['phone'],
        );
        DB::table('api')->insert($data);
    }
}
